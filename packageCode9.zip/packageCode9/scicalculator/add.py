
def add():
    nonb1 = float(input("antre yon premye nonb : "))
    nonb2 = float(input("antre yon dezyem nonb : "))
    result= add(nonb1, nonb2)
    print(f"som {nonb1} e {nonb2} se : {result}")

if __name__ == "__main__":
    addition()
