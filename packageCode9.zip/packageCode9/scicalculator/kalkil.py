def add(nonb1, nonb2):
    return nonb1 + nonb2

def subtract(nonb1, nonb2):
    return nonb1 - nonb2

def multiply(nonb1, nonb2):
    return nombre1 * nombre2

def divide(nonb1, nonb2):
    if nonb2 != 0:
        return nonb1 / nonb2
    else:
        return "li enposib pou w  divize yon nonb pa zewo"
