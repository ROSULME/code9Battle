def diviser():
	print("test division")