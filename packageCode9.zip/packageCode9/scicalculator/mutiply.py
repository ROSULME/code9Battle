
def multiply():
	nonb1 = float(input("antre yon premye nonb : "))
	nonb2= float(input("antre yon dezyem nonb : "))
    result = multiply(nonb1, nonb2)
    print(f"pwodui  {nonb1} e {nonb2} se : {result}")

if __name__ == "__main__":
    subtract()
