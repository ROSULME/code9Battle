
def subtract():
	nonb1 = float(input("antre yon premye nonb : "))
	nonb2= float(input("antre yon dezyem nonb : "))
	result = subtract(nonb1, nonb2)
	print(f"diferans ant {nonb1} e {nonb2} se : {result}")

if __name__ == "__main__":
    subtract()
