from scicalculator import add, subtract, multiple,divide


"""
add()
subtract()
multiple()
divide()
"""


def main():
    print("1. Addition")
    print("2. Soustraction")
    print("3. Multiplication")
    print("4. Division")

    antrUser= input("chwazi yon operasyon : ")

    if antrUser== "1":
        add()
    elif antrUser == "2":
        subtract()
    elif antrUser== "3":
        multiply()
    elif antrUser== "4":
        divide()
    else:
        print("chwa sa pa bon")

if __name__ == "__main__":
    main()
